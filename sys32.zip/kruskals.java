package kruskals;
import java.util.*;

public class kruskals{
	int[] parent = new int[10];
	
	int find(int m) {
		int p =m;
		while(parent[p]!=0) {
			p=parent[p];
		}
		return p;
	}
	
	void union(int i,int j) {
		if(i<j) {
			parent[i]=j;
		}
		else {
			parent[j]=i;
		}
	}
	
	void krk(int[][] w,int n) {
		int i,j,k=1,u=0,v=0,min,sum=0;
		while(k<n) {
			min=99;
			for(i=1;i<=n;i++) {
				for(j=1;j<=n;j++) {
					if(i!=j && min>w[i][j]) {
						min=w[i][j];
						u=i;
						v=j;
					}
				}
			}
			i=find(u);
			j=find(v);
			if(i!=j) {
				union(i,j);
				System.out.println(u+" -> "+v+" = "+min);
				sum+=min;
				k++;
			}
			w[v][u]=w[u][v]=99;
		}
		System.out.println("Cost of travel: "+sum);
	}
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of verticies: ");
		int n =sc.nextInt();
		System.out.println("Enter the weighted graph: ");
		int[][] w = new int[n+1][n+1];
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=n;j++) {
				w[i][j]=sc.nextInt();
			}
		}
		kruskals k = new kruskals();
		k.krk(w, n);
	}
}