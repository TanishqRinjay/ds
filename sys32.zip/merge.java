package merge;
import java.util.*;

public class merge {
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter n");
		int i, n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Enter array");
		for(i=0;i<n;i++) {
			a[i] = sc.nextInt();
		}
		Merge_Sort(a,0,n-1);
		for(i=0;i<n;i++) {
			System.out.print(a[i]+" ");
		}
	}
	
	public static void Merge_Sort(int[] a, int low, int high) {
		if(low<high) {
			int mid = (low+high)/2;
			Merge_Sort(a,low,mid);
			Merge_Sort(a,mid+1,high);
			Merge(a,low,mid,high);
		}
	}
	
	public static void Merge(int[] a, int low, int mid, int high) {
		int i=low,j=mid+1,k=low;
		int c[] = new int[a.length];
		while(i<=mid && j<=high) {
			if(a[i]>a[j]) {
				c[k]=a[j];
				k++;
				j++;
			}
			else {
				c[k]=a[i];
				k++;
				i++;
			}
		}
		while(i<=mid) {
			c[k]=a[i];
			k++;
			i++;
		}
		while(j<=high){
			c[k]=a[j];
			k++;
			j++;
		}
		for(i=low;i<=high;i++) {
			a[i]=c[i];
		}
	}
}
