package knapsack;
import java.util.*;

public class knapsack {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int i;
		System.out.println("Enter capacity: ");
		int C =sc.nextInt();
		System.out.println("Enter n: ");
		int n =sc.nextInt();
		int[] p = new int[n],w = new int[n],items = new int[n];
		float[] x = new float[n],p_w = new float[n];
		System.out.println("Enter profits and weights in order: ");
		for(i=0;i<n;i++) {
			p[i]=sc.nextInt();
			w[i]=sc.nextInt();
			p_w[i]=(float)p[i]/w[i];
			items[i]=i+1;
		}
		Selection_Sort(p_w,p,w,items,n);
		Knapsack(C,n,p,w,x);
		float sum=0;
		for(i=0;i<n;i++) {
			if(x[i]!=0) {
				System.out.println("Item "+items[i]+" was taken in fraction: "+x[i]);
				sum+=p[i]*x[i];
			}
		}
		System.out.println("Profit made: "+ sum);
		
	}
	public static void Selection_Sort(float[] p_w, int[] p, int[] w, int[] items, int n) {
		int t; float T;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(p_w[i]>p_w[j]) {
					
					T=p_w[i];
					p_w[i]=p_w[j];
					p_w[j]=T;
					
					t=p[i];
					p[i]=p[j];
					p[j]=t;
					
					t=w[i];
					w[i]=w[j];
					w[j]=t;
					
					t=items[i];
					items[i]=items[j];
					items[j]=t;
					
				}
			}
		}
	}
	public static void Knapsack(int C, int n, int[] p, int[] w, float[] x) {
		int i;
		for( i = 0;i<n;i++) {
			x[i]=0;
		}
		float weight =0;
		for(i=0;i<n;i++) {
			if(weight+w[i]<=C) {
				weight+=w[i];
				x[i]=1;
			}
			else {
				x[i]=(C-weight)/w[i];
				weight=C;
				
			}
		}
	}
}