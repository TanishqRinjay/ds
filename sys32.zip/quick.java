package quick;
import java.util.*;
public class quick {
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter n");
		int i, n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Enter array");
		for(i=0;i<n;i++) {
			a[i] = sc.nextInt();
		}
		Quick_Sort(a,0,n-1);
		for(i=0;i<n;i++) {
			System.out.print(a[i]+" ");
		}
	}
	
	public static void Quick_Sort(int[] a, int low, int high) {
		if(low<high) {
			int j= Partition(a,low,high+1);
			Quick_Sort(a,low,j-1);
			Quick_Sort(a,j+1,high);
		}
	}
	
	public static int Partition(int[] a, int low, int high) {
		int i=low,j=high,pivot=a[low],t;
		while(i<=j) {
			do {
				i++;
			}while(i<=high && a[i]<pivot);
			do {
				j--;
			}while(j>=low && a[j]>pivot);
			if(i<j) {
				t= a[i];
				a[i]=a[j];
				a[j] =t;
			}
		}
		t=a[low];
		a[low]=a[j];
		a[j]=t;
		return j;
	}
}
