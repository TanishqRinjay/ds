package selection;
import java.util.*;

public class selection {
	public static void main(String args[]) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter n");
		int i, n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Enter array");
		for(i=0;i<n;i++) {
			a[i] = sc.nextInt();
		}
		Selection_Sort(a,n);
		for(i=0;i<n;i++) {
			System.out.print(a[i]+" ");
		}
	}
	public static void Selection_Sort(int[] a, int n) {
		int i,j,min;
		for(i=0;i<n;i++) {
			min=i;
			for(j=i+1;j<n;j++) {
				if(a[j]<a[min]) {
					min=j;
				}
			}
			if(i!=min) {
				int t=a[i];
				a[i]=a[min];
				a[min]=t;
			}
		}
	}
}
