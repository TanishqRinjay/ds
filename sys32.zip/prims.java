package prims;
import java.util.*;

public class prims {
	public static void main(String args[]) {
		int i,j,k=0,s,u=0,v=0,min,sum=0,flag=0;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter number of verticies: ");
		int n = sc.nextInt();
		int[] sol = new int[n+1];
		int[][] w = new int[n+1][n+1];
		System.out.println("Enter source: ");
		s=sc.nextInt();
		for(i=1;i<=n;i++) {
			sol[i]=0;
		}
		System.out.println("Enter weighted graph: ");
		for(i=1;i<=n;i++) {
			for(j=1;j<=n;j++) {
				w[i][j]=sc.nextInt();
			}
		}
		sol[s]=1;
		k=1;
		while(k<n) {
			min=99;
			for(i=1;i<=n;i++) {
				for(j=1;j<=n;j++) {
					if(sol[i]==1 && sol[j]==0) {
						if(i!=j && min>w[i][j]) {
							min=w[i][j];
							u=i;
							v=j;
						}
					}
				}
			}
			sol[v]=1;
			sum+=min;
			k++;
			System.out.println(u+" -> "+v+" = "+min);
		}
		for(i=1;i<=n;i++) {
			if(sol[i]==0) {
				flag=1;
			}
		}
		if(flag==1) {
			System.out.println("No spanning tree");
		}
		else {
			System.out.println("Cost to travel: "+sum);
		}
	}
}