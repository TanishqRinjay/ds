def binaryToDecimal(binary):
    decimal, i = 0, 0
    while(binary != 0):
        dec = binary % 10
        decimal = decimal + dec * pow(2, i)
        binary = binary//10
        i += 1
    print(decimal)
    return decimal

def octalToDecimal(octal):
    decimal2, i = 0, 0
    while(octal != 0):
        oct2 = octal % 10
        decimal2 = decimal2 + oct2 * pow(8, i)
        octal = octal//10
        i += 1
    print(decimal2)
    return decimal2

def decToHexa(n):
    hexaDeciNum = ''
    while n != 0:
        temp = 0
        temp = n % 16
        if temp < 10:
            hexaDeciNum = str(temp) + hexaDeciNum
        else:
            hexaDeciNum = chr(temp + 87) + hexaDeciNum
        n = n // 16
    return hexaDeciNum

bin=int(input("Enter Binary number"))
bdecimal=binaryToDecimal(bin)
print("decimal number is",bdecimal)

octal=int(input("Enter Octal number"))
odecimal=octalToDecimal(octal)
print("decimal number for given octal number is",odecimal)

hex=decToHexa(odecimal)
print("Hexa-decimal number for given octal number is",hex)
