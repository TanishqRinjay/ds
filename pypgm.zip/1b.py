n = int(input("Enter number to be checked if it is Palindrome or not: "))
original = n
reverse = 0

while (n != 0):
    # Get the last digit of n
    remainder = n % 10
    # Add the remainder to the reverse after multiplying it by 10
    reverse = reverse * 10 + remainder
    # Remove the last digit of n by integer division
    n = n // 10
if (original == reverse):
    print("The given number", original, "is Palindrome")
else:
    print("The given number", original, "is NOT a Palindrome")
num = str(original)
for i in range(10):
    count = num.count(str(i))
    print("Number of occurrences of", i, "in", num, "is", count)
