def fib_series(n):
    n1 = 0
    n2 = 1
    if n == 1:
        print(n1)
    else:
        print(n1)
        print(n2)
        for i in range(2,n):
            t = n1 + n2
            n1 = n2
            n2 = t
            print(t)

fib=int(input("Enter how many number of elements in Fibonacci series: ")) 
fib_series(fib)
